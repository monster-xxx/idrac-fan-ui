from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
import subprocess, re, asyncio, json, os

app = FastAPI()
app.mount("/ui", StaticFiles(directory="frontend"), name="ui")

os.makedirs("data", exist_ok=True)
CONFIG_FILE = "data/config.json"
global_config = {}

def load_config():
    global global_config
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r") as f: global_config = json.load(f)
        except: pass

def save_config():
    with open(CONFIG_FILE, "w") as f: json.dump(global_config, f)

async def monitor_loop():
    while True:
        await asyncio.sleep(30)
        if not global_config.get("enabled", False): continue
        try:
            cfg = IPMIConfig(mode=global_config.get("mode", "network"), ip=global_config.get("ip", ""), user=global_config.get("user", ""), password=global_config.get("password", ""))
            res = run_ipmitool(cfg, "sdr type temperature")
            if "error" in res: continue
            max_t = 0
            for line in res["output"].splitlines():
                val = re.search(r'(\d+)\s+degrees C', line)
                if val: max_t = max(max_t, int(val.group(1)))
            if max_t >= int(global_config.get("threshold", 70)):
                run_ipmitool(cfg, "raw 0x30 0x30 0x01 0x01")
        except: pass

@app.on_event("startup")
async def startup_event():
    load_config(); asyncio.create_task(monitor_loop())

class IPMIConfig(BaseModel):
    mode: str; ip: str = ""; user: str = ""; password: str = ""

class FanControl(IPMIConfig):
    fan_mode: str; speed: int = 20

class ProtectConfig(BaseModel):
    mode: str; ip: str = ""; user: str = ""; password: str = ""; threshold: int; enabled: bool

def run_ipmitool(config: IPMIConfig, command: str):
    base_cmd = ["ipmitool"]
    if config.mode == "network":
        base_cmd.extend(["-I", "lanplus", "-H", config.ip, "-U", config.user, "-P", config.password])
    full_cmd = base_cmd + command.split()
    try:
        result = subprocess.run(full_cmd, capture_output=True, text=True, timeout=12)
        return {"output": result.stdout} if result.returncode == 0 else {"error": result.stderr}
    except Exception as e: return {"error": str(e)}

@app.get("/")
async def root():
    with open("frontend/index.html", "r", encoding="utf-8") as f: return HTMLResponse(content=f.read())

@app.get("/api/get_config")
async def get_cfg(): return global_config

@app.post("/api/save_config")
async def save_cfg(config: ProtectConfig):
    global global_config
    global_config = config.dict(); save_config()
    return {"status": "success", "message": "守护进程已同步"}

@app.post("/api/get_full_status")
async def get_full_status(config: IPMIConfig):
    t_res = run_ipmitool(config, "sdr type temperature")
    f_res = run_ipmitool(config, "sdr type Fan")
    # 使用 DCMI 指令获取 Dell 功耗
    p_res = run_ipmitool(config, "dcmi power reading")
    
    data = {"temps": {}, "fans": {}, "power": "N/A"}
    
    if "output" in t_res:
        for line in t_res["output"].splitlines():
            p = [i.strip() for i in line.split("|")]
            v = re.search(r'(\d+)\s+degrees C', p[4]) if len(p)>4 else None
            if v: data["temps"][p[0]] = int(v.group(1))
            
    if "output" in f_res:
        for line in f_res["output"].splitlines():
            p = [i.strip() for i in line.split("|")]
            v = re.search(r'(\d+)\s+RPM', p[4]) if len(p)>4 else None
            if v: data["fans"][p[0]] = int(v.group(1))

    # 解析功耗 (支持 dcmi 和 sdr 回退两种模式)
    if "output" in p_res:
        v = re.search(r'Instantaneous power reading:\s+(\d+)\s+Watts', p_res["output"], re.IGNORECASE)
        if v: 
            data["power"] = v.group(1)
        else:
            # 备选方案：直接查整个 sdr 列表里的 Pwr Consumption
            alt_res = run_ipmitool(config, "sdr")
            alt_v = re.search(r'Pwr Consumption.*?\|\s*(\d+)\s*Watts', alt_res.get("output", ""), re.IGNORECASE)
            if alt_v: data["power"] = alt_v.group(1)
        
    return {"status": "success", "data": data}

@app.post("/api/set_fan")
async def set_fan(config: FanControl):
    run_ipmitool(config, "raw 0x30 0x30 0x01 0x00")
    if config.fan_mode == "auto":
        run_ipmitool(config, "raw 0x30 0x30 0x01 0x01")
        return {"status": "success", "message": "官方托管已恢复"}
    hex_s = f"0x{config.speed if config.fan_mode != 'quiet' else 15:02x}"
    run_ipmitool(config, f"raw 0x30 0x30 0x02 0xff {hex_s}")
    return {"status": "success", "message": f"手动锁定: {hex_s}"}
